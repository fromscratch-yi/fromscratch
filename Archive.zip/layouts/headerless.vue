<template>
  <div class="wrap">
    <nuxt/>
  </div>
</template>

<style>
</style>
