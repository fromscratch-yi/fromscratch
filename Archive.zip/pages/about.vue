<script>
import About from '~/pages/_lang/about'
export default About
</script>