<script>
import Work from '~/pages/_lang/work'
export default Work
</script>