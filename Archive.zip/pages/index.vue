<script>
import Index from '~/pages/_lang/index'
export default Index
</script>