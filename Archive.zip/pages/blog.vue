<script>
import Blog from '~/pages/_lang/blog'
export default Blog
</script>